# encoding: utf-8
# ******************************************************
# Author       : zzw922cn
# Last modified: 2017-12-09 11:00
# Email        : zzw922cn@gmail.com
# Filename     : __init__.py
# Description  : Feature preprocessing for LibriSpeech dataset
# ******************************************************

from speechvalley.feature.libri.libri_preprocess import preprocess, wav2feature
